$(function() {
    $("h1").lettering();
  });